
public class Uno {

    public static int getUno() {
        return 1;
    }
}
