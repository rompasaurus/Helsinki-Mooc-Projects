package tmp;

public class Dummy {
}
