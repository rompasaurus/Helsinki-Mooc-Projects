
public class EvenNumbers {

    public static void main(String[] args) {
        for(int i=2;i<=100;i+=2){
            System.out.println(i);
        }
    }
}
