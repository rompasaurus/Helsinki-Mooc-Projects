
import java.util.Scanner;

public class Accounts {

    public static void main(String[] args) {
        // Code in Account.Java should not be touched!
        // write your code here
        Account account1 = new Account("owner",100.0);
        account1.deposit(20.0);
        System.out.println(account1);
    }

}
