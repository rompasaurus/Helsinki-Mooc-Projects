package moving.domain;

public interface Thing {
    int getVolume();
}
