public class Variables {

    public static void main(String[] args) {
        // CHANGE THESE:

        int chickenCount = 9000;
        double baconWeight = .1;
        String tractor = "Zetor";

        // DO NOT TOUCH THE BELOW:

        System.out.println("Chickens:");
        System.out.println(chickenCount);
        System.out.println("Bacon (kg):");
        System.out.println(baconWeight);
        System.out.println("A tractor:");
        System.out.println(tractor);
        System.out.println("");
        System.out.println("In a nutshell:");
        System.out.println(chickenCount);
        System.out.println(baconWeight);
        System.out.println(tractor);
    }

}
