
public interface ToBeStored {
    double weight();
}
