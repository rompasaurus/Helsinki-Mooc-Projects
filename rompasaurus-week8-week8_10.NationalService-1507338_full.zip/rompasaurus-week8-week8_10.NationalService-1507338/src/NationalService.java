public interface NationalService {
    int getDaysLeft();
    void work();
}
