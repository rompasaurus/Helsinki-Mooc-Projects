
public class Main {

    public static void main(String[] args) {
        // Write your main program here. Implementing your own classes will be very useful.
        UI ui = new UI();
        ui.start();
    }
}
