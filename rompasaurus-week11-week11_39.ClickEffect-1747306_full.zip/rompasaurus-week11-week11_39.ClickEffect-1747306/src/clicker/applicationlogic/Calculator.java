package clicker.applicationlogic;

public interface Calculator {
    int giveValue();
    void increase();
}
