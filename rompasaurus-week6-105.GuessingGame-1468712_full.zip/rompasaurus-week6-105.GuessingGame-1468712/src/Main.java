
public class Main {
    public static void main(String[] args) {
        // test your program here
        GuessingGame game = new GuessingGame();
        game.play(1,10);
    }    
}
