public class Main {
    public static void main(String[] args) {
        // You can test your new class here, try e.g.:
        
        Product t = new Product("Banana", 1.1, 13);
        // t.printProduct();
        //Product banana = new Product();
        t.printProduct();
    }
}
