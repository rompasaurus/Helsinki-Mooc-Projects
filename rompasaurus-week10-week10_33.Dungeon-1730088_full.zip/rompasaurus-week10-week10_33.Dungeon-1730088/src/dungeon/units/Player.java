package dungeon.units;

public class Player extends Unit {

    public Player(int xLocation, int yLocation) {
        super(xLocation, yLocation, '@');
    }
}
