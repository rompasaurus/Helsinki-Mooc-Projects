package dungeon.units;

public class UnitChecker extends Unit {
    public UnitChecker(int xLocation, int yLocation) {
        super(xLocation, yLocation, '-');
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }
}
