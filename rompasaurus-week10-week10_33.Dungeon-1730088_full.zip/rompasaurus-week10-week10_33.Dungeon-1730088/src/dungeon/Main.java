package dungeon;


public class Main {
    public static void main(String[] args) {
        new Dungeon(5,5,5,5,false).run();
    }
}
