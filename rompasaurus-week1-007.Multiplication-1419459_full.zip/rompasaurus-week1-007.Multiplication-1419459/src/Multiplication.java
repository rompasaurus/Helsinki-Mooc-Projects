public class Multiplication {

    public static void main(String[] args) {

        int a = 1337;
        int b = 42;
        int result=a*b;
        System.out.println(a+" * "+b+" = "+result);
        // Program your solution here. Remember to use variables a and b!
    }

}
