package farmsimulator;

public interface Milkable {
    double milk();
}
